# APS Case Summarizer

This is a simple Flask web app that allows users to paste or upload email threads and get a summarized version in bullet points.

## Features

- Paste text or upload a file
- Click "Summarize" to generate bullet-point summary
- Copy the summary to clipboard

## Setup Instructions

1. Install Python 3 and pip if not already installed.
2. Create a virtual environment (optional but recommended):
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
3. Install Flask:
   pip install flask
4. Run the app:
   python app.py
5. Open your browser and go to http://127.0.0.1:5000
