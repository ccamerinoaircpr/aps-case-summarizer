from flask import Flask, request, render_template_string, jsonify

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>APS Case Summarizer</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        textarea { width: 100%; height: 200px; margin-bottom: 20px; }
        .section { margin-bottom: 30px; }
        button { padding: 10px 20px; font-size: 16px; }
        #summary { background-color: #f4f4f4; padding: 15px; border: 1px solid #ccc; white-space: pre-wrap; }
    </style>
</head>
<body>
    <h1>APS Case Summarizer</h1>

    <div class="section">
        <h3>Paste Email Thread or Upload File</h3>
        <form id="summarizerForm" enctype="multipart/form-data">
            <textarea name="textInput" placeholder="Paste your email thread here..."></textarea><br>
            <input type="file" name="fileInput"><br><br>
            <button type="submit">Summarize</button>
        </form>
    </div>

    <div class="section">
        <h3>Summary</h3>
        <div id="summary"></div>
        <button onclick="copySummary()">Copy</button>
    </div>

    <script>
        function copySummary() {
            const summaryText = document.getElementById("summary").innerText;
            navigator.clipboard.writeText(summaryText).then(() => {
                alert("Summary copied to clipboard!");
            });
        }

        document.getElementById("summarizerForm").addEventListener("submit", function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch("/summarize", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById("summary").innerText = data.summary;
            });
        });
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/summarize', methods=['POST'])
def summarize():
    text_input = request.form.get('textInput', '')
    file = request.files.get('fileInput')

    content = text_input
    if file:
        content += '\n' + file.read().decode('utf-8', errors='ignore')

    lines = [line.strip() for line in content.split('\n') if line.strip()]
    bullet_points = '\n'.join(f"- {line}" for line in lines[:5])

    return jsonify({'summary': bullet_points})

if __name__ == '__main__':
    app.run(debug=True)
